from django.contrib import admin
from .models import Citizen

admin.site.register(Citizen)